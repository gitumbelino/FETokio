let altura = 10;
let largura = 30;

let areaQuadrado = altura * largura;

let areaTriangulo = 0.5 * altura * largura;

console.log (`a area do quadrado é ${areaQuadrado}`);
console.log (`a area do triângulo é ${areaTriangulo}`);




